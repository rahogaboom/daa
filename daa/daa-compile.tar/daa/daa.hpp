#ifndef DAA_HPP
#define DAA_HPP

/*
 * File: daa.hpp
 *
 * Description:
 *     header file for daa.cpp - dynamic array allocator
 *
 */

/*
 * global variables
 */

extern const char *daa_errs[];

/*
 * Author: Richard Hogaboom
 * richard.hogaboom@gmail.com
 */

   int
das(
   unsigned int data_size,
   unsigned int num_dim,
   unsigned int *dim,
   int *err_code);

   void *
daa(
   unsigned int data_size,
   unsigned int num_dim,
   unsigned int *dim,
   int *st,
   int *err_code,
   char *base_ptr,
   char *init_ptr);

#endif
